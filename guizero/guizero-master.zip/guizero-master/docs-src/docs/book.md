# Book

### Create Graphical User Interfaces with Python

The authors of guizero have written a book containing ten fun guizero projects. The book starts from a very basic GUI and shows you how to create gradually more complex GUI programs including a painting program and a stop-motion animation creator.

You can download it as a [free PDF](https://magpi.raspberrypi.org/books/create-guis).

![guizero book](images/guizero-book.jpg)
